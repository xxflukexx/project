<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลการศึกษา</title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header-login.php'; ?>
    <?php include 'navbar-login.php'; ?>
    <div class="register-page">
        <div class="register-box">
            <h2>ข้อมูลการศึกษา</h2>
            <form action="register3.php" method="post">
                <!-- ชื่อสถานศึกษา -->
                <div class="form-group">
                    <label>ชื่อสถานศึกษาเดิม</label>
                    <input type="text" placeholder="ชื่อสถานศึกษาเดิม">
                </div>
                <!-- วุฒิการศึกษา -->
                <div class="form-group">
                    <label>วุฒิการศึกษาที่จบ</label>
                    <div class="radio-group">
                        <label>
                            <input type="radio" name="education" value="ม.6">
                            ม.6
                        </label>
                        <label>
                            <input type="radio" name="education" value="ปวช">
                            ปวช.
                        </label>
                        <label>
                            <input type="radio" name="education" value="ปวส">
                            ปวส.
                        </label>
                    </div>
                </div>


                <!-- แผนการเรียน -->
                <div class="form-group">
                    <label>แผนการเรียน</label>
                    <input type="text" placeholder="รายวิชา/แผนการเรียน">
                </div>


                <!-- สาขาวิชา -->
                <div class="form-group">
                    <label>สาขาวิชา</label>
                    <input type="text" placeholder="สาขาวิชา">
                </div>


                <!-- เกรด -->
                <div class="form-group">
                    <label>เกรดเฉลี่ยสะสม</label>
                    <input type="number" step="0.01" min="0" max="4" placeholder="เกรดเฉลี่ย">

                </div>


                <!-- แนบเอกสาร -->
                <div class="form-group">
                    <label>แนบใบปพ.</label>
                    <label class="upload-box">
                        <div class="upload-img">
                            <img src="img/upload.png" alt="" srcset="" id="fileInput">
                        </div>
                        <p>Browse Files to upload</p>
                        <input type="file" >
                    </label>
                </div>


                <!-- ปุ่ม -->
                <div class="form-button">
                    <div class="button-group">
                        <a href="register.php" class="back-button">
                            ย้อนกลับ
                        </a>
                        <button type="submit">
                            ถัดไป
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    <script>
        cconst uploadBox = document.querySelector('.upload-box');
const fileInput = document.querySelector('.upload-box input[type="file"]');

uploadBox.addEventListener('click', () => {
    fileInput.click();
});
    </script>
</body>

</html>