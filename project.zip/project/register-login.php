<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>สมัครนักศึกษา</title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include 'header-login.php'; ?>

    <?php include 'navbar-login.php'; ?>

    <div class="register-page">

        <div class="register-box">

            <h2>สมัครนักศึกษา</h2>

            <form action="register2.php" method="get">

                <!-- ชื่อ - นามสกุล -->
                <div class="form-row">

                    <div class="form-group">
                        <label>ชื่อ</label>
                        <input
                            type="text"
                            placeholder="ชื่อ">
                    </div>

                    <div class="form-group">
                        <label>นามสกุล</label>
                        <input
                            type="text"
                            placeholder="นามสกุล">
                    </div>

                </div>


                <!-- อีเมล -->
                <div class="form-group">
                    <label>อีเมล</label>
                    <input
                        type="email"
                        placeholder="example@gmail.com">
                </div>


                <!-- รหัสผ่าน -->
                <div class="form-row">

                    <div class="form-group">
                        <label>รหัสผ่าน</label>
                        <input
                            type="password"
                            placeholder="รหัสผ่าน">
                    </div>

                    <div class="form-group">
                        <label>ยืนยันรหัสผ่าน</label>
                        <input
                            type="password"
                            placeholder="ยืนยันรหัสผ่าน">
                    </div>

                </div>


                <!-- เบอร์โทร -->
                <div class="form-group">
                    <label>เบอร์โทร</label>
                    <input
                        type="tel"
                        placeholder="000-000-0000">
                </div>


                <!-- เลขบัตรประชาชน -->
                <div class="form-group">
                    <label>เลขบัตรประชาชน</label>
                    <input
                        type="text"
                        placeholder="0-0000-00000-00-0">
                </div>


                <!-- สัญชาติ -->
                <div class="form-group">
                    <label>สัญชาติ</label>
                    <input
                        type="text"
                        placeholder="สัญชาติ">
                </div>


                <!-- ศาสนา -->
                <div class="form-group">
                    <label>ศาสนา</label>
                    <input
                        type="text"
                        placeholder="ศาสนา">
                </div>


                <!-- วันเกิด -->
                <div class="form-group">
                    <label>วันเกิด</label>
                    <input type="date">
                </div>


                <!-- เพศ -->
                <div class="form-group">

                    <label>เพศ</label>

                    <div class="radio-group">

                        <label>
                            <input
                                type="radio"
                                name="gender">
                            ชาย
                        </label>

                        <label>
                            <input
                                type="radio"
                                name="gender">
                            หญิง
                        </label>

                        <label>
                            <input
                                type="radio"
                                name="gender">
                            อื่นๆ
                        </label>

                    </div>

                </div>


                <!-- ที่อยู่ -->
                <div class="form-group">

                    <label>ที่อยู่</label>

                    <textarea
                        rows="4"
                        placeholder="ที่อยู่"></textarea>

                </div>


                <!-- ปุ่ม -->
                <div class="form-button">

                    <a href="login.php" class="login-link">
                        มีบัญชีอยู่แล้ว? | เข้าสู่ระบบ
                    </a>

                    <button type="submit">
                        ต่อไป
                    </button>

                </div>

            </form>

        </div>

    </div>

    <?php include 'footer.php'; ?>

</body>
</html>