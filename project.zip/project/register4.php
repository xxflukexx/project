<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลติดต่อ</title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <?php include 'header-login.php'; ?>
    <?php include 'navbar-login.php'; ?>
    <div class="register-page">

        <div class="register-box">

            <h2>ข้อมูลติดต่อ</h2>

            <form action="index-login.php">

                <!-- จังหวัด -->
                <div class="form-group">
                    <label>จังหวัด</label>
                    <input
                        type="text"
                        placeholder="จังหวัด">
                </div>


                <!-- รหัสไปรษณีย์ -->
                <div class="form-group">

                    <label>รหัสไปรษณีย์</label>

                    <input
                        type="text"
                        placeholder="รหัสไปรษณีย์">

                </div>


                <!-- ผู้ติดต่อฉุกเฉิน -->
                <div class="form-group">

                    <label>ผู้ติดต่อฉุกเฉิน</label>

                    <input
                        type="text"
                        placeholder="ผู้ติดต่อฉุกเฉิน">

                </div>


                <!-- ความสัมพันธ์ -->
                <div class="form-group">

                    <label>ความสัมพันธ์</label>

                    <input
                        type="text"
                        placeholder="ความสัมพันธ์">

                </div>


                <!-- เบอร์โทรผู้ติดต่อ -->
                <div class="form-group">

                    <label>เบอร์โทรผู้ติดต่อ</label>

                    <input
                        type="tel"
                        placeholder="เบอร์โทรผู้ติดต่อ">

                </div>


                <!-- ปุ่ม -->
                <div class="form-button">

                    <div class="button-group">

                        <a
                            href="register3.php"
                            class="back-button">
                            ย้อนกลับ
                        </a>

                        <button type="submit" id="btn">สมัครเรียน</button>
                    </div>

                </div>

            </form>

        </div>

    </div>
    <div class="overlay" id="overlay"></div>
    <div class="alert-container" id="alert">
        <h1>สมัครสำเร็จ !!</h1>
        <div class="alert-container-bottom">
            <center>
                <button type="button" id="home-btn"> กลับไปหน้าแรก </button>
            </center>
        </div> 
    </div>
</div>
    <?php include 'footer.php'; ?>
    <script>
    overlay = document.getElementById("overlay")
    alertbox = document.getElementById("alert")
    overlay.hidden = true;
    alertbox.hidden = true;
    
    document.getElementById("btn").addEventListener("click", function (event) {
        event.preventDefault();
        alertbox.hidden = false;

        overlay.hidden = false;
    });
    document.getElementById("home-btn").addEventListener("click", function () {
        window.location.href = "index-login.php";
    });
</script>
</body> 
</html>