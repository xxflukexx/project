<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ข้อมูลการสมัคร</title>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'header-login.php'; ?>
    <?php include 'navbar-login.php'; ?>
    <div class="register-page">
        <div class="register-box">
            <h2>ข้อมูลการสมัคร</h2>
            <form action="register4.php" method="post"> 
                <!-- ================= คณะ ================= -->
                <div class="form-group">
                    <label for="faculty"> เลือกคณะ </label>
                    <select id="faculty" name="faculty" required>
                        <option value=""> เลือกคณะ </option>
                        <option value="คณะเทคโนโลยีสารสนเทศ"> คณะเทคโนโลยีสารสนเทศ </option>
                        <option value="คณะวิศวกรรมศาสตร์"> คณะวิศวกรรมศาสตร์ </option>
                        <option value="คณะบริหารธุรกิจ"> คณะบริหารธุรกิจ </option>
                        <option value="คณะเกษตรศาสตร์"> คณะเกษตรศาสตร์ </option>
                    </select> 
                </div> 
                    <!-- ================= สาขา ================= -->
                <div class="form-group"> 
                    <label for="major"> เลือกสาขา</label> 
                    <select id="major" name="major" required>
                        <option value=""> เลือกสาขา </option>
                        <option value="เทคโนโลยีสารสนเทศ"> เทคโนโลยีสารสนเทศ </option>
                        <option value="วิศวกรรมสารสนเทศและเครือข่าย"> วิศวกรรมสารสนเทศและเครือข่าย </option>
                        <option value="วิทยาการคอมพิวเตอร์"> วิทยาการคอมพิวเตอร์ </option>
                        <option value="การจัดการ"> การจัดการ </option>
                    </select>
                </div>
                <!-- ================= รอบที่สมัคร ================= -->
                <div class="form-group">
                    <label for="round"> รอบที่สมัคร</label>
                    <select id="round" name="round" required>
                        <option value=""> เลือกรอบ </option>
                        <option value="รอบที่ 1"> รอบที่ 1 </option>
                        <option value="รอบที่ 2"> รอบที่ 2 </option>
                        <option value="รอบที่ 3"> รอบที่ 3 </option>
                        <option value="รอบที่ 4"> รอบที่ 4 </option>
                    </select>
                </div> 
                <!-- ================= สาขาลำดับที่สอง ================= -->
                <div class="form-group"> <label for="second_major"> เลือกสาขาลำดับที่สอง </label> <select
                        id="second_major" name="second_major">
                        <option value=""> ไม่เลือกสาขาลำดับที่สอง </option>
                        <option value="เทคโนโลยีสารสนเทศ"> สาขาเทคโนโลยีสารสนเทศ </option>
                        <option value="วิศวกรรมสารสนเทศและเครือข่าย"> สาขาวิศวกรรมสารสนเทศและเครือข่าย </option>
                        <option value="เทคโนโลยีเครื่องกลและกระบวนการผลิต"> สาขาเทคโนโลยีเครื่องกลและกระบวนการผลิต
                        </option>
                    </select> 
                </div> 
                <!-- ================= ปุ่ม ================= -->
                <div class="form-button">
                    <div class="button-group"> 
                        <a href="register2.php" class="back-button"> ย้อนกลับ </a>
                        <button type="submit">ถัดไป</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php include 'footer.php'; ?>
</body>

</html>